package com.todoapp.leanix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToDoAppLeanIxApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToDoAppLeanIxApplication.class, args);
	}

}
