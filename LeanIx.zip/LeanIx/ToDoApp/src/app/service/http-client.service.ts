import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export class Task{
  constructor(
    public taskId:Number,
    public name:string,
    public description:string,
  ) {} 
}

export class Todo{
  constructor(
    public todoId:Number,
    public name:string,
    public description:string,
    public tasks:Task,
  ) {}
}


@Injectable({
  providedIn: 'root'
})


export class HttpClientService {
  

  constructor(private httpClient:HttpClient) { }

getAllTodo()
  {
    console.log("test call");
    return this.httpClient.get<Todo[]>('http://localhost:8080/todos');
  }
  public deleteTodo(todo) {
    console.log('delete call');
    return this.httpClient.delete<Todo>("http://localhost:8080/todos" + "/"+ todo.todoId);
  }

  public createTodo(todo) {
    console.log('create call');
    return this.httpClient.post<Todo>("http://localhost:8080/todos", todo);
  }
 

}
