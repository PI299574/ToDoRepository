import { Component, OnInit } from '@angular/core';
import { HttpClientService, Todo } from '../service/http-client.service';

@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css']
})
export class AddTodoComponent implements OnInit {

  todo:Todo=new Todo(0,"","",null);

  constructor(
    private httpClientService: HttpClientService
    ) { }

  ngOnInit() {
  }
  createTodo(): void {
    this.httpClientService.createTodo(this.todo)
        .subscribe( data => {
          alert("todo created successfully.");
        });

  };
}
