import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {TodoComponent} from './Todo/Todo.component';
import { AddTodoComponent } from './add-todo/add-todo.component';
const routes: Routes = [
  { path:'', component: TodoComponent},
  { path:'todo', component: TodoComponent},
  { path:'addtodo', component: AddTodoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
 