import { Component, OnInit } from '@angular/core';
import { HttpClientService, Todo } from '../service/http-client.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  todos: any;

  constructor(
    private httpClientService:HttpClientService
  ) { }

  ngOnInit() {
    this.httpClientService.getAllTodo().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response)
  {
      this.todos=response;
  }
  deleteTodo(todo: Todo): void {
    console.log('In delete Todo****'+todo);
    this.httpClientService.deleteTodo(todo)
      .subscribe( data => {
        this.todos = this.todos.filter(u => u !== todo);
      })
  };
}
